
import './App.css';
import {usestate} from 'react'
function App() {
  let [products,setProducts]=usestate([ ]);
  let fetchProducts=()=>{
    fetch('https://fakestoreapi.com/products').then(resp => resp.json()).then(json => {
    setProducts(json);  
    // console.log(json)
    });
  }
  return (
  <>
  <div className='container '>
  <h1>Fakestore API Web</h1>
   {(products.length !== 0) ? <>
    <div className='row'>
     {
      products.map((product, index)=>(
        <>
         <div className='col-lg-4'>
        <div className='card'>
          <div className='card-image'>
            product image
          </div>
          <div className='card-body'>
           <h3 style={{margin:"0px"}}>Product Name</h3>
           <p style={{margin:"0px"}}>Product Discription</p>
          </div>
          <div className='card-footer'>
          <div className='row'>
          <div className='col-lg-6'>
           <h2 style={{margin:"0px"}}>Rs.888</h2>
          </div>
          <div className='col-lg-6'>
            <button style={{ width:"100%"}} className="btn btn-primary">Add To Cart</button>
          </div>
          </div>
          </div>
        </div>
      </div>
        </>
      ))
     }
    </div>
    </>:<>
    <div className='alert alert-danger'>products not loaded...</div>
    <button className='btn btn-primary' onClick={(e)=>{
      e.preventDefault();
      e.target.innerText= 'please wait...';
      fetchProducts();
      }}>fetch products</button>
    </>}
  </div>
  </>
  );
}

export default App;
