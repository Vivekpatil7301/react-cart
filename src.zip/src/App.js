import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';
import Cart from './Components/Cart';

function App() {
  let[products,setProducts] = useState([]);
  let [search, setSearch] = useState('');
  let [page, setPage] = useState('products');
  let [cart, setCart] = useState((localStorage.getItem('cart') === null || localStorage.getItem('cart') === undefined) ? [] : JSON.parse(localStorage.getItem('cart')));
  let fetchProducts=()=>{
    fetch('https://fakestoreapi.com/products').then(resp => resp.json()).then(json => {
    setProducts(json);  
    // console.log(json)
    });
  }

  useEffect(() => {
    fetchProducts();
  }, []);

  const addToCart = (item) => {
    cart.push(item);
    setCart([...cart]);
    localStorage.setItem("cart", JSON.stringify(cart));
  }

  const deleteItem = (item) => {
    cart.splice(item, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    setCart([...cart]);
  }

  return (
    <>
      <div className='container '>
     
    { (page === 'products') ? <>
    <h1>Fakestore API Web (Cart Items : { cart.length }) <button className='btn btn-sm btn-primary' onClick={ (e) => {
      e.preventDefault();
      setPage('cart');
     } }>View Cart</button></h1>
     <input type='text' placeholder='Search Products...' className='form-control mb-3' value={ search } onChange={ (e) => {
      e.preventDefault();
      setSearch(e.target.value);
     } } />
    {(products.length !==0)? <>
    <div className='row'>
    { products.filter(prds => (prds.title).toLowerCase().includes(search.toLowerCase()) || (prds.description).toLowerCase().includes(search.toLowerCase()) || (Math.round(prds.price)).toString() == search.toLowerCase()).map((product, index)=>(
        <>
         <div className='col-lg-3 mb-2'>
        <div className='card shadow-sm'>
          <div className='card-image p-3 text-center'>
            <img src={product.image} style={{height:'200px'}} className='img-fluid'></img>
          </div>
          <div className='card-body'>
           <h3 style={{margin:"0px"}}>{(product.title).substring(0,10)}...</h3>
           <p style={{margin:"0px"}}>{(product.description).substring(0, 100)}...</p>
          </div>
          <div className='card-footer'>
          <div className='row'>
          <div className='col-lg-5'>
           <h2 style={{margin:"0px", fontWeight:'bold'}}>${Math.round(product.price)}</h2>
          </div>
          <div className='col-lg-7'>
            <button style={{ width:"100%"}} className="btn btn-primary" onClick={(e)=>{
              e.preventDefault();
              e.target.innerText='Added';
              e.target.className='btn btn-outline-success';
              addToCart(product);
              setTimeout(() => {
                e.target.innerText = 'Add To Cart';
                e.target.className = 'btn btn-primary';
              }, 1500);
            }}>Add To Cart</button>
          </div>
          </div>
          </div>
        </div>
      </div>
        </>
      ))
     }
     </div>
   </> :<>
   <div className='alert alert-danger'>products not loaded...</div>

   <button className='btn btn-primary' onClick={(e)=>{
      e.preventDefault();
      e.target.innerText= 'please wait...';
      fetchProducts();
      }}>fetch products</button>
   </>}
    </> : <>
    <h1>Fakestore API Web <button className='btn btn-sm btn-primary' onClick={ (e) => {
      e.preventDefault();
      setPage('products');
     } }>View Products</button></h1>
      <Cart items={ cart } deleteItem={ deleteItem } />
    </> }
</div>
    </>
  )
}

export default App;