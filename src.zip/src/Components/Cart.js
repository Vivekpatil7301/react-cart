import React, {useState} from "react";
 //import  from useState;

function Cart({ items, deleteItem }){

    
    const getCartTotal = () => {
        let grandTotal = 0;
        items.map(itm => {
            grandTotal += Math.round(itm.price);
        })
        return grandTotal;
    }
    let [search, setSearch] = useState('');

   
    
    return(
        
        <>
            <div className="row">
                <div className="col-lg-6"><h1 style={{ float: "left" }}>Cart</h1></div> <div className="col-lg-6"><h1 style={{ float: "right" }}>Cart Total : ${ Math.round(getCartTotal()) }</h1>
                </div>



            <input type='text' placeholder="seach" className="form-control mb-3" onChange={ (e) => {
      e.preventDefault();
      setSearch(e.target.value);
     } } />
            
            </div>


            {
                (items.length !== 0) ? <>
                    <div className="row">

                      
                    {  items.filter(prds => (prds.title).toLowerCase().includes(search.toLowerCase()) || (prds.description).toLowerCase().includes(search.toLowerCase()) || (Math.round(prds.price)).toString() == search.toLowerCase()).map((item, index) => (
                        <div className="col-lg-12 mb-3">
                            <div className="card shadow-sm">
                                <div className="card-body">
                                    <div className="row">
                                        <div className="col-lg-1" style={{ display: "flex", aligItems: "center", justifyContent: "center" }}>
                                            <img src={ item.image } className='img-fluid'  />
                                        </div>
                                        <div className="col-lg-9" style={{ display: "flex", aligItems: "center", justifyContent: "center" }}>
                                            <div>
                                            <h4>{ (item.title).substring(0, 25) }...</h4>
                                            <p>{ item.description }</p>  
                                                </div>  
                                        </div>
                                        <div className="col-lg-2 text-center" style={{ display: "flex", aligItems: "center", justifyContent: "center" }}>
                                            <div><h1>${ Math.round(item.price) }</h1>
                                            <button className="btn btn-danger" onClick={(e) => {
                                                e.preventDefault();
                                                e.target.innerText = 'Please wait...';
                                                setTimeout(() => {
                                                    deleteItem(index);
                                                }, 1000);
                                            }}>Delete Product</button></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )) }
                    </div>
                </>
                : <>
                    <h3 className="alert alert-danger shadow">No Items In Cart</h3>
                </>
            }
        </>
    );
}

export default Cart